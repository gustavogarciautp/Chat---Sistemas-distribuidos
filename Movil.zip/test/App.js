import React from 'react';

import Navigation from './components/navigation';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TextInput,
  Alert,
  Picker,
} from 'react-native';

//import SocketContext from './components/context'
import io from 'socket.io-client';
///const net= require('react-native-tcp');
//var client = net.createConnection(3000);

//const socket = io('192.168.0.13:8000');

export default class App extends React.Component {
    constructor (props){
      super(props)
       this.socket = io('http://192.168.0.13:8000');
    }


    componentDidMount(){
        //Alert.alert('fdfd',this.socket.id);
    }
    
    validacion(){
      var registro={"Nombre":'jj',"Apellido":'yyy',"Login":'uuul',"Password":'ttt',"Edad":'jj',"Genero":'hhh'}
    this.socket.emit('Registrarse',registro, (arg)=>{
        Alert.alert('fff',arg);
    })
    }


  render() {
    return (
      <View>
            <Button
                title="sss" 
              />
            <Button
                title="ff" onPress={this.validacion.bind(this)}
              />
        </View>
    );
  }
}

