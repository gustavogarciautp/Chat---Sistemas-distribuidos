import React from 'react';
import { StyleSheet, Text, View, Image, Button, TextInput ,Alert} from 'react-native';
import { createStackNavigator, createAppContainer } from 'react-navigation';
import { AsyncStorage } from "react-native"
import SocketContext from './context'

class Inicio_sesion_class extends React.Component {
  constructor(props) {
    super(props);
     this.state = { text: ''};
  }

    componentWillMount() {
      this.props.socket.emit('new-message-added','hola')
  }

    render() {
      return (
        <View style={{flex: 1, flexDirection: 'row', padding:0}}>
          <View style={{flex:0.4, flexDirection:'column', justifyContent:'center', backgroundColor: '#B8CDE3'}}>
            <View style={{height:100}}>
              <Image source={require('./../assets/logo.png')}
            style={{height:80, width:80, marginLeft: 'auto',marginRight: 'auto'}}/>  

            </View>
          </View>
          <View style={{backgroundColor: '#6D7B8F',flex:0.6, flexDirection: 'column', justifyContent: 'center'}}>
            <View style={{paddingLeft:20, paddingRight:20}}>
              <TextInput
              style={{height: 40, backgroundColor: 'white', marginBottom:50, textAlign:"center"}}
              placeholder="Usuario"
              onChangeText={(text) => this.setState({text})}
              value={this.state.text}
              />

              <TextInput style={{height: 40, backgroundColor: 'white', marginBottom:50, textAlign:"center"}}
                placeholder="Contraseña"
                onChangeText={(text) => this.setState({text})}
              />

              <Button
                title="Aceptar"
              />
            </View>
          </View>
        </View>
      );
    }
  }



const Inicio_sesion = props => (
  <SocketContext.Consumer>
    {socket => <Inicio_sesion_class {...props} socket={socket} />}
  </SocketContext.Consumer>
)


export default Inicio_sesion