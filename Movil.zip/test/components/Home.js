import React from 'react';
import { StyleSheet, Text, View, Image, Button, TextInput ,Alert} from 'react-native';
import { createStackNavigator, createAppContainer } from 'react-navigation';

export default class Home extends React.Component {
  constructor(props) {
    super(props);
     this.state = { text: ''};
  }
    render() {
      const {navigate} = this.props.navigation;
      return (
        <View>
            <Button
                title="Iniciar Sesion" onPress={()=>navigate('Sesion', {name: 'Jane'})}
              />
            <Button
                title="Registrar" onPress={()=>navigate('Registro', {name: 'Jane'})}
              />
            </View>
      );
    }
  }