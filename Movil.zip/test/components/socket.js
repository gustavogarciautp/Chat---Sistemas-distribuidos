const io = require ( 'socket.io-client' );
import {Alert} from 'react-native';

const socket = io('http://localhost:8000');

socket.on('mensaje', (args)=>{
    Alert.alert(args);
})

function mensajesala(msg){
    socket.emit('mensaje',{"Mensaje":msg})
}
    
function registrarse(data){
    socket.emit('Registrarse',data, (arg)=>{
        Alert.alert(arg)
    })
}

function startsesion(l){
    console.log(l[0])
    console.log(l[1])
    console.log(l)
    var cad={"Login":"cr7","Password":"juventus"}
    socket.emit('startsession',cad,(arg)=>{
        console.log(arg)
    })
    console.log("end")
}

function crearsala(nombreSala){
    socket.emit('crearsala',nombreSala,(arg)=>{
        console.log(arg)
    })
}

function entrarsala(nombreSala){
    socket.emit('entrarsala',nombreSala,(arg)=>{
        console.log(arg);
    })
}

function salirsala(){
    socket.emit('salir')
}

function msgprivado(r,msg){
    var cad={"Receptor":r,"Mensaje":msg}
    socket.emit('private',cad)
}

function exit(){
    socket.emit('desconectar')
}

function showusers(){
    socket.emit('show_users',(arg)=>{
        console.log(arg)
    })
}

function listarsalas(){
    socket.emit('listarsalas',(arg)=>{
        console.log(arg)
    })
}

function eliminarsala(){
    socket.emit('eliminarsala',(arg)=>{
        console.log(arg)
    })
}

