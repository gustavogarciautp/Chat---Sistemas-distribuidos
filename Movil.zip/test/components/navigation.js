import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { createStackNavigator, createAppContainer } from "react-navigation";

import Inicio_sesion from './Inicio_sesion';
import Registrar from './Registrar';
import Home from './Home';


const AppNavigator = createStackNavigator(
  {
    Sesion: Inicio_sesion,
    Registro: Registrar,
    Home: Home
  },
  {
    initialRouteName: "Home"
  }
);

export default createAppContainer(AppNavigator);